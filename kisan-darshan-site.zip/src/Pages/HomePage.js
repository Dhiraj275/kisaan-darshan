import React from 'react'
import '../style/templatemo-style.css'
import famerImg from '../assets/images/home-farmer.jpg'
function HomePage() {
    return (
        <>
            <div className="container">
                <div className="placeholder">
                    <div className="parallax-window" data-parallax="scroll" data-image-src="img/home-farmer.jpg">
                        <div className="tm-header">
                            <div className="row tm-header-inner">
                                <div className="col-md-6 col-12">
                                    <img src={famerImg} alt="Logo" className="tm-site-logo" /> 
                                    <div className="tm-site-text-box">
                                        <h1 className="tm-site-title">KISHAN DARSHAN</h1>
                                        <h6 className="tm-site-description">Our Slogan here if any</h6>
                                    </div>
                                </div>
                                <nav className="col-md-6 col-12 tm-nav">
                                    <ul className="tm-nav-ul">
                                        <li className="tm-nav-li"><a href="homepage.html" className="tm-nav-link active">Home</a></li>
                                        <li className="tm-nav-li"><a href="about.html" className="tm-nav-link">About</a></li>
                                        <li className="tm-nav-li"><a href="contact.html" className="tm-nav-link">Contact</a></li>
                                        <li className="tm-nav-li"><a href="login-as.html" className="tm-nav-link">Login</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>

                {/* <main>
                    <header className="row tm-welcome-section">
                        <h2 className="col-12 text-center tm-section-title">Welcome to Kishan Darshan</h2>
                        <p className="col-12 text-center">----About the Website ------
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque vel libero obcaecati ullam, dolorem error alias natus veniam labore quis eaque deserunt ratione. Molestiae, voluptas. Ad maiores corporis nobis adipisci aliquam facilis earum?
                        </p>
                    </header>

                    <div className="tm-paging-links">
                        <nav>
                            <ul>
                                <li className="tm-paging-item"><a href="#vege" className="tm-paging-link">Vegetables</a></li>
                                <li className="tm-paging-item"><a href="#p-and-i" className="tm-paging-link">Pesticides and Insectisides</a></li>
                                <li className="tm-paging-item"><a href="#mac" className="tm-paging-link">Machineries</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div id="products">
                        <br id="vege">
                        </br>
                        <center><h1>Vegetables</h1></center>
                        <div id="vegetables">
                            <article className="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                                <figure>
                                    <img src="img/lemon.jpg" alt="Image" className="img-fluid tm-gallery-img" />
                                    <figcaption>
                                        <h4 className="tm-gallery-title">Lemon</h4>
                                        <p className="tm-gallery-description">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                        <p className="tm-gallery-price">Rs. 50/kg</p>
                                    </figcaption>
                                </figure>
                            </article>
                            <article className="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                                <figure>
                                    <img src="img/cucumber.jpg" alt="Image" className="img-fluid tm-gallery-img" />
                                    <figcaption>
                                        <h4 className="tm-gallery-title">Cucumber</h4>
                                        <p className="tm-gallery-description">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                        <p className="tm-gallery-price">Rs. 10/kg</p>
                                    </figcaption>
                                </figure>
                            </article>
                            <article className="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                                <figure>
                                    <img src="img/tomato.jpg" alt="Image" className="img-fluid tm-gallery-img" />
                                    <figcaption>
                                        <h4 className="tm-gallery-title" translate="no">Tomato</h4>
                                        <p className="tm-gallery-description">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                        <p className="tm-gallery-price">Rs. 25/kg</p>
                                    </figcaption>
                                </figure>
                            </article>
                            <article className="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                                <figure>
                                    <img src="img/okra.jpg" alt="Image" className="img-fluid tm-gallery-img" />
                                    <figcaption>
                                        <h4 className="tm-gallery-title" translate="no">Bhindi/Okra</h4>
                                        <p className="tm-gallery-description">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                        <p className="tm-gallery-price">Rs. 25/kg</p>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>


                        <br id="p-and-i">
                        </br>
                        <center><h1>Pesticides and Insectisides</h1></center>

                        <div id="pesticides-and-insectisides">
                            <article className="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                                <figure>
                                    <img src="img/insec1.jpg" alt="Image" className="img-fluid tm-gallery-img" />
                                    <figcaption>
                                        <h4 className="tm-gallery-title">Insectisides1</h4>
                                        <p className="tm-gallery-description">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                        <p className="tm-gallery-price">Rs. 520</p>
                                    </figcaption>
                                </figure>
                            </article>
                            <article className="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                                <figure>
                                    <img src="img/insec2.jpg" alt="Image" className="img-fluid tm-gallery-img" />
                                    <figcaption>
                                        <h4 className="tm-gallery-title">Insectisides2</h4>
                                        <p className="tm-gallery-description">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                        <p className="tm-gallery-price">Rs. 180</p>
                                    </figcaption>
                                </figure>
                            </article>
                            <article className="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                                <figure>
                                    <img src="img/insec3.jpg" alt="Image" className="img-fluid tm-gallery-img" />
                                    <figcaption>
                                        <h4 className="tm-gallery-title" translate="no">Insectiside 3</h4>
                                        <p className="tm-gallery-description">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                        <p className="tm-gallery-price">Rs. 230</p>
                                    </figcaption>
                                </figure>
                            </article>
                            <article className="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                                <figure>
                                    <img src="img/insec4.jpeg" alt="Image" className="img-fluid tm-gallery-img" />
                                    <figcaption>
                                        <h4 className="tm-gallery-title" translate="no">Insectiside 4</h4>
                                        <p className="tm-gallery-description">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                        <p className="tm-gallery-price">Rs. 280</p>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>


                        <br id="mac">
                            <br />
                            <center><h1>Machineries</h1></center>
                        </br>
                        <br />
                        <div id="machineries">
                            <article className="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                                <figure>
                                    <img src="img/tractor.jpg" alt="Image" className="img-fluid tm-gallery-img" />
                                    <figcaption>
                                        <h4 className="tm-gallery-title" translate="no">Insectiside 3</h4>
                                        <p className="tm-gallery-description">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                        <p className="tm-gallery-price">Rs. 8,89,000</p>
                                    </figcaption>
                                </figure>
                            </article>
                            <article className="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                                <figure>
                                    <img src="img/motor.jpg" alt="Image" className="img-fluid tm-gallery-img" />
                                    <figcaption>
                                        <h4 className="tm-gallery-title" translate="no">Pesticide Spreader</h4>
                                        <p className="tm-gallery-description">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                        <p className="tm-gallery-price">Rs. 7800</p>
                                    </figcaption>
                                </figure>
                            </article>
                            <article className="col-lg-3 col-md-4 col-sm-6 col-12 tm-gallery-item">
                                <figure>
                                    <img src="img/plogh2.jpg" alt="Image" className="img-fluid tm-gallery-img" />
                                    <figcaption>
                                        <h4 className="tm-gallery-title" translate="no">Tool Name</h4>
                                        <p className="tm-gallery-description">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                                        <p className="tm-gallery-price">Rs. 460</p>
                                    </figcaption>
                                </figure>
                            </article>
                        </div>
                    </div>

                    <div className="tm-section tm-container-inner">
                        <div className="row">
                            <div className="col-md-6">
                                <figure className="tm-description-figure">
                                    <img src="img/call-help.jpg" alt="Image" height="100px" className="img-fluid" />
                                </figure>
                            </div>
                            <div className="col-md-6">
                                <div className="tm-description-box">
                                    <h4 className="tm-gallery-title">Expert Call</h4>
                                    <p className="tm-mb-45">
                                        <br />
                                        <br />
                                        If you have any Query
                                        <br />
                                        feel free to <a href="http://">request a Call</a> or <a href="contact.html">Leave a Messege here</a>
                                    </p>
                                    <a href="about.html" className="tm-btn tm-btn-default tm-right">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </main> */}
            </div>

            {/* <footer className="tm-footer text-center">
                <p>Copyright &copy; 2022 Example name</p>
            </footer> */}
        </>
    )
}

export default HomePage