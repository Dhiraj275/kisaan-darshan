import {Route,Routes} from 'react-router-dom'
import KDIndex from "./Pages/KDIndex";
import HomePage from './Pages/HomePage';
function App() {
  return (

          <Routes>
           <Route exact path="/" element={<KDIndex/>}/>
           <Route exact path="/home" element={<HomePage/>}/>
          </Routes>
      );
}

export default App;
